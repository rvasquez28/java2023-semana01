package org.example;

import org.librerias.Funciones;

public class Main {
    public static void main(String[] args) {


        //System.out.println("Clase 1 de java");

        Alumno objAlumno01 = new Alumno(1, "Ray", 12, 13, 15);
        Alumno objAlumno02 = new Alumno(2, "Juan", 12, 13, 15);
        Alumno objAlumno03 = new Alumno(3, "Maria", 12, 13, 15);


        //Llamar al metdo de la clase alumno

        objAlumno01.mensaje();

        objAlumno01.mensajeParametro("Hola soy ray");

        objAlumno01.mensajeAtributo();


        //Sale nmbre
        objAlumno01.setNombres("Ray Vasquez");
        objAlumno01.mensajeAtributo();


        // Alumno objAlumno02 = new Alumno();
        // objAlumno02.mensajeAtributo();


        double promedio = objAlumno01.promedio();
        objAlumno01.mensajeParametro(String.valueOf(promedio));


//LLAMAR A LA CLASE FUNCIONES
        Funciones objFunciones = new Funciones("Saludar");
        objFunciones.saludar();


    }
}